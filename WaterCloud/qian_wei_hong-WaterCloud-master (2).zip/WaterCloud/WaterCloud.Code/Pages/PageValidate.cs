﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WaterCloud.Code
{
    public partial class PageValidate
    {
        /// <summary>
        /// 没得该方法的源码，返回空
        /// </summary>
        /// <param name="xu"></param>
        /// <param name="defaultValue"></param>
        /// <returns></returns>
        public static string SafeLongFilter(string xu, int defaultValue) {
            return "";
        }
    }
}
