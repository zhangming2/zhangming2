﻿/*******************************************************************************
 * Copyright © 2020 WaterCloud.Framework 版权所有
 * Author: WaterCloud
 * Description: WaterCloud快速开发平台
 * Website：
*********************************************************************************/

namespace WaterCloud.DataBase.Extensions
{
    /// <summary>
    /// 实体接口相关扩展
    /// </summary>
    public static class EntityInterfaceExtensions
    {
        
    }
}
