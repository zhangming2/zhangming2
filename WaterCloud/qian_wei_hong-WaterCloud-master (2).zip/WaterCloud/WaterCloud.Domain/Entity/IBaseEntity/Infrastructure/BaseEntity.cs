﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WaterCloud.Code;


namespace WaterCloud.Entity
{
    public class BaseEntity<TEntity>
    {
        //public int D_Id { get; set; }
        //public DateTime? D_AddTime { get; set; }
        public void Create()
        {

        }
        
    }
}
