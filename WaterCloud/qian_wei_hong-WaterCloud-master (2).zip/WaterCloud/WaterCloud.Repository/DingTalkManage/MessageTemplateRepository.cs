﻿/*******************************************************************************
 * Copyright © 2018 WaterCloud 版权所有
 * Author: WaterCloud
 * Description: WaterCloud
 * Website：
*********************************************************************************/

using WaterCloud.DataBase;
using WaterCloud.Entity.DingTalkManage;


namespace WaterCloud.Repository.DingTalkManage 
{
	//DingTalk_MessageTemplate
	public class MessageTemplateRepository : RepositoryBase<MessageTemplateEntity>, IRepositoryBase<MessageTemplateEntity>
	{
   		
	}
}

