﻿/*******************************************************************************
 * Copyright © 2018 WaterCloud 版权所有
 * Author: WaterCloud
 * Description: WaterCloud
 * Website：
*********************************************************************************/

using WaterCloud.DataBase;
using WaterCloud.Entity.WeixinManage;


namespace WaterCloud.Repository.WeixinManage 
{
	//微信用户基本表
	public class UsersRepository : RepositoryBase<UsersEntity>, IRepositoryBase<UsersEntity>
	{
   		
	}
}

