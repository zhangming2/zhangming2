﻿/*******************************************************************************
 * Copyright © 2018 WaterCloud 版权所有
 * Author: WaterCloud
 * Description: WaterCloud开发平台
 * Website：
*********************************************************************************/
using WaterCloud.DataBase;
using WaterCloud.Entity.WeixinManage;

namespace WaterCloud.Repository.WeixinManage
{
    public class WxPropertyInfoRepository : RepositoryBase<WxPropertyInfoEntity>, IRepositoryBase<WxPropertyInfoEntity>
    {

    }
}
