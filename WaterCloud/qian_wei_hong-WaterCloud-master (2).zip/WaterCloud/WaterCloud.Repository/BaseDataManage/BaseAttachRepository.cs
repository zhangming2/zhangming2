﻿/*******************************************************************************
 * Copyright © 2018 WaterCloud 版权所有
 * Author: WaterCloud
 * Description: WaterCloud
 * Website：
*********************************************************************************/

using WaterCloud.DataBase;
using WaterCloud.Entity.BaseDataManage;


namespace WaterCloud.Repository.BaseDataManage
{
    //KnowledgeBase_Attach
    public class BaseAttachRepository : RepositoryBase<BaseAttachEntity>, IRepositoryBase<BaseAttachEntity>
    {

    }
}

