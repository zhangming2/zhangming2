﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WaterCloud.WeixinMP
{
    public class WxMenu
    {
        public string Top1 { get; set; }
        public string Top1Url { get; set; }
        public string Top1Key { get; set; }
        public string Top2 { get; set; }
        public string Top2Url { get; set; }
        public string Top2Key { get; set; }
        public string Top3 { get; set; }
        public string Top3Url { get; set; }
        public string Top3Key { get; set; }

        public string Menu11 { get; set; }
        public string Menu11Key { get; set; }
        public string Menu11Url { get; set; }

        public string Menu12 { get; set; }
        public string Menu12Key { get; set; }
        public string Menu12Url { get; set; }

        public string Menu13 { get; set; }
        public string Menu13Key { get; set; }
        public string Menu13Url { get; set; }

        public string Menu14 { get; set; }
        public string Menu14Key { get; set; }
        public string Menu14Url { get; set; }

        public string Menu15 { get; set; }
        public string Menu15Key { get; set; }
        public string Menu15Url { get; set; }

        public string Menu21 { get; set; }
        public string Menu21Key { get; set; }
        public string Menu21Url { get; set; }

        public string Menu22 { get; set; }
        public string Menu22Key { get; set; }
        public string Menu22Url { get; set; }

        public string Menu23 { get; set; }
        public string Menu23Key { get; set; }
        public string Menu23Url { get; set; }

        public string Menu24 { get; set; }
        public string Menu24Key { get; set; }
        public string Menu24Url { get; set; }

        public string Menu25 { get; set; }
        public string Menu25Key { get; set; }
        public string Menu25Url { get; set; }

        public string Menu31 { get; set; }
        public string Menu31Key { get; set; }
        public string Menu31Url { get; set; }

        public string Menu32 { get; set; }
        public string Menu32Key { get; set; }
        public string Menu32Url { get; set; }

        public string Menu33 { get; set; }
        public string Menu33Key { get; set; }
        public string Menu33Url { get; set; }

        public string Menu34 { get; set; }
        public string Menu34Key { get; set; }
        public string Menu34Url { get; set; }

        public string Menu35 { get; set; }
        public string Menu35Key { get; set; }
        public string Menu35Url { get; set; }
    }
}
